const discord = require("discord.js");

module.exports.run = async (bot, message, args) => {

    var regels = message.guild.channels.find("name", "👂regels");

    if (!regels) return message.channel.send("Ik kan het regels kanaal niet vinden.");

    message.channel.send(`Je kunt de regels vinden in ${regels}`);

};

module.exports.help = {
    name: "regels"
}