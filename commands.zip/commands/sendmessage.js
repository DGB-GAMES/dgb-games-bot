const discord = require("discord.js");

module.exports.run = async (bot, message, args) => {

    if (!message.member.roles.find("name", "BotPerms"))

        return message.reply(":no_entry_sign: Je hebt geen toegang tot dit commando! :no_entry_sign:");

    var user = message.guild.member(message.mentions.users.first() || message.guild.members.get(args[0]));

    if (!user) return message.channel.send(":warning: Geef een gebruiker op!");

    var text = args.join(" ").slice(22);

    if (!text) return message.channel.send(":warning: Geef een reden op!");

    message.delete().catch(O_o=>{});
    user.send(`${text}`);

}

module.exports.help = {
    name: "senduser"
}