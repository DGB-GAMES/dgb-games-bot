const discord = require("discord.js");

module.exports.run = async (bot, message, args) => {

    var number = 11;
    imageNumber = Math.floor (Math.random() * (number - 1 + 1)) + 1;
    message.channel.send ({ files: ["./images/" + imageNumber + ".png"]})

}

module.exports.help = {
    name: "aapje"
}