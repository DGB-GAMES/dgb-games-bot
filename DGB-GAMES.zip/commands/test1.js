const discord = require("discord.js");

module.exports.run = async (bot, message, args) => {

    if (!message.member.roles.find("name", "BotPerms"))

        return message.reply(":no_entry_sign: Je hebt geen toegang tot dit commando! :no_entry_sign:");

    var rMember = message.guild.member(message.mentions.users.first() || message.guild.members.get(args[0]));

    if (!rMember) return message.channel.send(":warning: Geef een gebruiker op!")

    var role = args.join(" ").slice(22);

    if (!role) return message.channel.send(":warning: Geef een rol op!")

    var gRole = message.guild.roles.find("name", role);

    if (!gRole) return message.channel.send(":warning: Ik kan deze rol niet vinden!")

    if (rMember.roles.has(gRole));

    await

    (rMember.addRole(gRole))

    await message.channel.send(`${rMember} heeft nu de ${gRole} rol gekregen!`)

}

module.exports.help = {
    name: "addrole"
}