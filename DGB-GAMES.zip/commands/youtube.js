const discord = require("discord.js");

module.exports.run = async (bot, message, args) => {

    return message.channel.send("Dit commando is nog niet beschikbaar!");

}

module.exports.help = {
    name: "youtube"
}