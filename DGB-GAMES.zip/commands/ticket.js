const discord = require("discord.js");

module.exports.run = async (bot, message, args) => {

    const categoryId = "506445924910891009";

    var userName = message.author.username;
    var userDiscriminator = message.author.discriminator

    var bool = false;

    message.guild.channels.forEach((channel) => {

        if (channel.name == userName.toLowerCase() + "-" + userDiscriminator) {

            message.channel.send(":warning: Je hebt al een ticket aangemaakt!")

            bool = true;

        }

    });

    if (bool == true) return;

    var embedCreateTicket = new discord.RichEmbed()
        .setTitle(":white_check_mark: Je ticket is aangemaakt!")

        message.channel.send(embedCreateTicket);

        message.guild.createChannel(userName + "-" + userDiscriminator, "text").then((createdChan) => {

            createdChan.setParent(categoryId).then((settedParent) => {

                settedParent.overwritePermissions(message.guild.roles.find('name', "@everyone"), { "READ_MESSAGES": false });
                

                settedParent.overwritePermissions(message.author, {

                    "READ_MESSAGES": true, "SEND_MESSAGES": true,
                    "ATTACH_FILES": true, "CONNECT": true,
                    "CREATE_INSTANT_INVITE": false, "ADDED_REACTIONS": true,

                });

                var embedParent = new discord.RichEmbed()
                .setTitle("Welkom in het ticket kanaal" + " " + message.author.username + "!")
                .setDescription("Stel hier je vraag of opmerking en iemand van het Support Team zal je helpen!")

                settedParent.send(embedParent)
                

            }).catch(err =>{
                message.channel.send("Er is iets fout gegaan!")
            });

        }).catch(err =>{
            message.channel.send("Er is iets fout gegaan!")
        });

}

module.exports.help = {
    name: "new"
};