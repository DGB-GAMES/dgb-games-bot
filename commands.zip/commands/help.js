const discord = require("discord.js");

module.exports.run = async (bot, message, args) => {

    const botIcon = bot.user.displayAvatarURL;

    const botEmbed = new discord.RichEmbed()
        .setTitle("__**Bot Commands:**__")
        .setColor("#29e53f")
        .setThumbnail(botIcon)
        .addField(":gear: /help", "==========")
        .addField(":clipboard: /botinfo", "==========")
        .addField(":movie_camera: /youtube", "==========")
        .addField(":pager: /new", "==========")
        .addField(":iphone: /staff-help", "==========")
        .addField("**Overige Commando's:**", "==========")
        .addField(":monkey: /aapje", "==========")
        .addField(":gem: /niels", "==========")
        .setFooter("DGB-GAMES" + " | " + "By Melvin#7592", botIcon)

        return message.channel.send(botEmbed);

    };

module.exports.help = {
    name: "help" 
}