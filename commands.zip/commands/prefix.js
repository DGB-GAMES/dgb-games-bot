const discord = require("discord.js");
const fs = require("fs");

module.exports.run = async (bot, message, args) => {

    if (!message.member.hasPermission("MANAGE_SERVER")) return message.channel.send(":warning: Je hebt geen toegang voor dit command!");

    if(!args[0]) return message.channel.send(":warning: Geef een prefix op!")

    var prefixes = JSON.parse(fs.readFileSync("./data/prefixes.json"));

    prefixes[message.guild.id] = {
        prefixes: args[0]
    };

    fs.writeFileSync("./data/prefixes.json", JSON.stringify(prefixes), (err) => {
        if (err) console.log(err);
    });

    var stringEmbed = new discord.RichEmbed()
    .setColor("#F00")
    .setTitle("Prefix")
    .setDescription(`Prefix aangepast naar ${args[0]}`);

    message.channel.send(stringEmbed);

}

module.exports.help = {
    name: "prefix"
}