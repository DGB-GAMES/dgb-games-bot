const discord = require("discord.js");

module.exports.run = async (bot, message, args) => {

    const botIcon = bot.user.displayAvatarURL;

    const helpEmbed = new discord.RichEmbed()
    .setTitle("__**Bot Informatie:**__")
    .setColor("#29e53f")
    .setThumbnail(botIcon)
    .addField("Bot naam:", bot.user.username)
    .addField("Gemaakt op:", bot.user.createdAt)
    .addField("Gemaakt door:", message.guild.owner)
    .setFooter("DGB-GAMES" + " | " + "By Melvin#7592", botIcon)

    return message.channel.send(helpEmbed);

};

module.exports.help = {
    name: "botinfo"
}