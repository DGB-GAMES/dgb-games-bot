const discord = require("discord.js");
const ms = require("ms");

module.exports.run = async (bot, message, args) => {

    if (!message.member.roles.find("name", "BotPerms"))

        return message.reply(":no_entry_sign: Je hebt geen toegang tot dit commando! :no_entry_sign:");

    var user = message.guild.member(message.mentions.users.first() || message.guild.members.get(args[0]));

    if (!user) return message.channel.send(":warning: Geef een gebruiker op!");

    if (!user.hasPermission("ADMINISTRATOR"))
     
        return message.channel.send(":warning: Je kunt deze gebruiker niet muten!");

    var muteRole = message.guild.roles.find("name", "Muted");

    if (!muteRole) return message.channel.send("Ik kan de muted rank niet vinden.")

    var muteTime = args[1];

    if (!muteTime) return message.channel.send(":warning: Geef een tijd op!")

    await (user.addRole(muteRole.id));

    message.channel.send(`${user} is muted voor ${muteTime}.`);

    setTimeout(function () {

        user.removeRole(muteRole.id);

        message.channel.send(`${user} is unmuted.`)

    }, ms(muteTime));


}

module.exports.help = {
    name: "mute"
}


