const discord = require("discord.js");

module.exports.run = async (bot, message, args) => {

    const botIcon = bot.user.displayAvatarURL;

    const helpEmbed = new discord.RichEmbed()
    .setTitle("__**Gebruiker Informatie:**__")
    .setColor('RANDOM')
    .setThumbnail(botIcon)
    .addBlankField()
    .addField("Username:", message.author.username + message.author.discriminator)
    .addField("Join Position:", message.member.joinedAt)
    .setFooter("DGB-GAMES" + " | " + "By Melvin#7592", botIcon)

    return message.channel.send(helpEmbed);

};

module.exports.help = {
    name: "userinfo"
}