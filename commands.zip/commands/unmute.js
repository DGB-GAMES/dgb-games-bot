const discord = require("discord.js");
const ms = require("ms");

module.exports.run = async (bot, message, args) => {

    if (!message.member.roles.find("name", "BotPerms"))

        return message.reply(":no_entry_sign: Je hebt geen toegang tot dit commando! :no_entry_sign:");

    var user = message.guild.member(message.mentions.users.first() || message.guild.members.get(args[0]));

    if (!user) return message.channel.send(":warning: Geef een gebruiker op!");

    var muteRole = message.guild.roles.find("name", "Muted");

    if (!muteRole) return message.channel.send("Ik kan de muted rank niet vinden.")

    
    await (user.removeRole(muteRole.id));

    message.channel.send(`${user} is unmuted.`);

}

module.exports.help = {
    name: "unmute"
}


