const discord = require("discord.js");
const ms = require("ms");

module.exports.run = async (bot, message, args) => {

    if (!message.member.roles.find("name", "Staff"))

    return message.reply(":no_entry_sign: Je hebt geen toegang tot dit commando! :no_entry_sign:");

    const botIcon = bot.user.displayAvatarURL;

    const staffEmbed = new discord.RichEmbed()
        .setTitle("__**Staff Commands:**__")
        .setColor("#29e53f")
        .setThumbnail(botIcon)
        .addField(":hammer: /warn", "==========")
        .addField(":mute: /mute", "==========")
        .addField(":loud_sound: /unmute", "==========")
        .addField(":outbox_tray: /senduser", "==========")
        .setFooter("DGB-GAMES" + " | " + "By Melvin#7592", botIcon)

        return message.author.send(staffEmbed);

}

module.exports.help = {
    name: "staff-help"
}


