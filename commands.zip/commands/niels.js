const discord = require("discord.js");

module.exports.run = async (bot, message, args) => {

    return message.channel.send("Check zeker dit Youtube kanaal! https://www.youtube.com/channel/UCTfFEO-mBXyni8iCu6uKldg");

}

module.exports.help = {
    name: "niels"
}