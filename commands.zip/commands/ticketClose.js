const discord = require("discord.js");

module.exports.run = async (bot, message, args) => {

    const categoryId = "506445924910891009";

    if (message.channel.parentID == categoryId) {

        message.channel.delete()

    } else {

        message.channel.send(":warning: Je kunt dit commando alleen in een ticket kanaal gebruiken!");
    };


    var embedCloseTicket = new discord.RichEmbed()
        .setTitle("Ticket" + " " + message.channel.name)
        .setDescription(":no_entry_sign: Dit ticket is gesloten!")
        .addBlankField()
        .addField("Ticket gesloten door:", message.author.username + message.author.discriminator)
        

    var logChannel = message.guild.channels.find("name", "owners")

    if (!logChannel) return message.channel.send(":warning: Dit kanaal bestaat niet!")


    logChannel.send(embedCloseTicket);

};

module.exports.help = {
    name: "close"
};