const discord = require("discord.js");
const fs = require("fs");

const warns = JSON.parse(fs.readFileSync("./data/warnings.json", "utf8"));

module.exports.run = async (bot, message, args) => {

    /// /warn @User#0000 [Reden] ///

    if (!message.member.roles.find("name", "BotPerms"))

        return message.reply(":no_entry_sign: Je hebt geen toegang tot dit commando! :no_entry_sign:");


    
        var user = message.guild.member(message.mentions.users.first() || message.guild.members.get(args[0]));

    if (!user) return message.channel.send(":warning: Geef een gebruiker op!");



    var reason = args.join(" ").slice(22);

    if (!reason) return message.channel.send(":warning: Geef een reden op!");

    if (!warns[user.id]) warns[user.id] = {
        warns: 0
    };

    warns[user.id].warns++;

    fs.writeFile("./data/warnings.json", JSON.stringify(warns), (err) => {
        if (err) console.log(err);
    });

    var warnEmbed = new discord.RichEmbed()
        .setTitle("__**Nieuwe Warning!**__")
        .setColor("#ee0000")
        .addField("Gewarnde gebruiker:", user)
        .addField("Gewarned door:", message.author)
        .addField("Reden:", reason)
        .addField("Aantal warns:", warns[user.id].warns)
        .addField("User ID:", user.id)

    var warnChannel = message.guild.channels.find(`name`, "warnings");
    if (!warnChannel) return message.guild.send(":warning: Ik kan het warn channel niet vinden!")

    message.delete().catch(O_o=>{});
    warnChannel.send(warnEmbed)

    user.send(`Je hebt een warning gekregen op de DGB-GAMES server!\n\n**Reden:** ${reason}\n\n**Gewarned door:** ${message.author}\n\n**Aantal warnings:** ${warns[user.id].warns}`);

}

module.exports.help = {
    name: "warn"
}